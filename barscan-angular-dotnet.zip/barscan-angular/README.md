# BarScan Pro — Angular 19 + .NET 10

## Structure
```
barscan-angular/
├── backend/BarscanApi/    → ASP.NET Core 10 Web API + SQLite
└── frontend/              → Angular 19 Standalone
```

## Démarrer le Backend

```bash
cd backend/BarscanApi
dotnet run
# API disponible sur http://localhost:5000
```

## Démarrer le Frontend

```bash
cd frontend
npm install
npm start
# App disponible sur http://localhost:4200
```

## Accès
- App : http://localhost:4200
- Opérateur : entrer un nom, rôle Opérateur
- Admin : entrer un nom, rôle Admin, mot de passe : admin123

## Changer le mot de passe admin
Modifier `backend/BarscanApi/appsettings.json` :
```json
{
  "AdminPass": "nouveau_mot_de_passe"
}
```

## Accès réseau usine
1. Lancer le backend : `dotnet run --urls "http://0.0.0.0:5000"`
2. Modifier `frontend/src/app/services/api.service.ts` ligne 10 :
   ```ts
   private base = 'http://[IP_DU_SERVEUR]:5000/api';
   ```
3. Builder Angular : `npm run build`
4. Copier `frontend/dist/barscan-frontend/browser/` dans `backend/BarscanApi/wwwroot/`
5. Lancer uniquement le backend : `dotnet run`
6. Accéder depuis tous les postes : `http://[IP_DU_SERVEUR]:5000`
