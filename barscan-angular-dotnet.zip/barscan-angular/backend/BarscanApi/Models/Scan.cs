namespace BarscanApi.Models;

public class Scan
{
    public int Id { get; set; }
    public string Barcode1 { get; set; } = string.Empty;
    public string Barcode2 { get; set; } = string.Empty;
    public string Result { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public DateTime ScannedAt { get; set; } = DateTime.UtcNow;
}
