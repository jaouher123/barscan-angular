using BarscanApi.Data;
using BarscanApi.DTOs;
using BarscanApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace BarscanApi.Controllers;

[ApiController]
[Route("api/scans")]
public class ScansController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;

    public ScansController(AppDbContext db, IConfiguration config)
    {
        _db = db;
        _config = config;
    }

    private bool IsAdmin()
    {
        var adminPass = _config["AdminPass"] ?? "admin123";
        var pass = Request.Headers["x-admin-pass"].FirstOrDefault()
                   ?? Request.Query["adminPass"].FirstOrDefault();
        return pass == adminPass;
    }

    // POST /api/scans/compare
    [HttpPost("compare")]
    public async Task<IActionResult> Compare([FromBody] CompareRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Barcode1) || string.IsNullOrWhiteSpace(req.Barcode2))
            return BadRequest(new { error = "Codes manquants" });

        var result = req.Barcode1 == req.Barcode2 ? "OK" : "NOK";
        var user = string.IsNullOrWhiteSpace(req.Username) ? "inconnu" : req.Username;
        var now = DateTime.UtcNow;

        var scan = new Scan
        {
            Barcode1 = req.Barcode1,
            Barcode2 = req.Barcode2,
            Result = result,
            Username = user,
            ScannedAt = now
        };

        _db.Scans.Add(scan);
        await _db.SaveChangesAsync();

        var today = DateOnly.FromDateTime(now);
        var stats = await _db.Scans
            .Where(s => s.Username == user && DateOnly.FromDateTime(s.ScannedAt) == today)
            .GroupBy(s => 1)
            .Select(g => new StatsDto(
                g.Count(),
                g.Count(s => s.Result == "OK"),
                g.Count(s => s.Result == "NOK"),
                g.Count() > 0 ? (double)g.Count(s => s.Result == "NOK") / g.Count() * 100 : 0
            ))
            .FirstOrDefaultAsync() ?? new StatsDto(0, 0, 0, 0);

        var scanDto = new ScanDto(scan.Id, scan.Barcode1, scan.Barcode2, scan.Result, scan.Username, scan.ScannedAt);
        return Ok(new CompareResponse(scanDto, stats));
    }

    // GET /api/scans/history
    [HttpGet("history")]
    public async Task<IActionResult> History(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 25,
        [FromQuery] string? searchCode = null,
        [FromQuery] string? result = null,
        [FromQuery] string? username = null)
    {
        var query = _db.Scans.AsQueryable();

        if (!string.IsNullOrWhiteSpace(searchCode))
            query = query.Where(s => s.Barcode1.Contains(searchCode)
                                  || s.Barcode2.Contains(searchCode)
                                  || s.Username.Contains(searchCode));

        if (!string.IsNullOrWhiteSpace(result))
            query = query.Where(s => s.Result == result);

        if (!string.IsNullOrWhiteSpace(username))
            query = query.Where(s => s.Username == username);

        var rows = await query
            .OrderByDescending(s => s.ScannedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(s => new ScanDto(s.Id, s.Barcode1, s.Barcode2, s.Result, s.Username, s.ScannedAt))
            .ToListAsync();

        return Ok(rows);
    }

    // GET /api/scans/stats
    [HttpGet("stats")]
    public async Task<IActionResult> Stats([FromQuery] string? username = null)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var query = _db.Scans.Where(s => DateOnly.FromDateTime(s.ScannedAt) == today);

        if (!string.IsNullOrWhiteSpace(username))
            query = query.Where(s => s.Username == username);

        var stats = await query
            .GroupBy(s => 1)
            .Select(g => new StatsDto(
                g.Count(),
                g.Count(s => s.Result == "OK"),
                g.Count(s => s.Result == "NOK"),
                g.Count() > 0 ? (double)g.Count(s => s.Result == "NOK") / g.Count() * 100 : 0
            ))
            .FirstOrDefaultAsync() ?? new StatsDto(0, 0, 0, 0);

        return Ok(stats);
    }

    // GET /api/scans/hourly
    [HttpGet("hourly")]
    public async Task<IActionResult> Hourly()
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var rows = await _db.Scans
            .Where(s => DateOnly.FromDateTime(s.ScannedAt) == today)
            .GroupBy(s => s.ScannedAt.Hour)
            .Select(g => new HourlyDto(
                g.Key,
                g.Count(s => s.Result == "OK"),
                g.Count(s => s.Result == "NOK")
            ))
            .OrderBy(h => h.Hour)
            .ToListAsync();

        return Ok(rows);
    }

    // GET /api/scans/export
    [HttpGet("export")]
    public async Task<IActionResult> Export([FromQuery] string? username = null)
    {
        var query = _db.Scans.AsQueryable();
        if (!string.IsNullOrWhiteSpace(username))
            query = query.Where(s => s.Username == username);

        var rows = await query.OrderByDescending(s => s.ScannedAt).ToListAsync();

        var sb = new StringBuilder("\uFEFFDate/Heure,Code 1,Code 2,Résultat,Opérateur\n");
        foreach (var r in rows)
            sb.AppendLine($"\"{r.ScannedAt:yyyy-MM-dd HH:mm:ss}\",\"{r.Barcode1}\",\"{r.Barcode2}\",\"{r.Result}\",\"{r.Username}\"");

        return File(Encoding.UTF8.GetBytes(sb.ToString()), "text/csv", "scans.csv");
    }

    // DELETE /api/scans/all
    [HttpDelete("all")]
    public async Task<IActionResult> DeleteAll()
    {
        if (!IsAdmin()) return Unauthorized(new { error = "Non autorisé" });
        await _db.Scans.ExecuteDeleteAsync();
        return Ok(new { ok = true });
    }
}
