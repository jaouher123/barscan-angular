using BarscanApi.Data;
using BarscanApi.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BarscanApi.Controllers;

[ApiController]
[Route("api/admin")]
public class AdminController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;

    public AdminController(AppDbContext db, IConfiguration config)
    {
        _db = db;
        _config = config;
    }

    private bool IsAdmin()
    {
        var adminPass = _config["AdminPass"] ?? "admin123";
        var pass = Request.Headers["x-admin-pass"].FirstOrDefault()
                   ?? Request.Query["adminPass"].FirstOrDefault();
        return pass == adminPass;
    }

    // GET /api/admin/clients
    [HttpGet("clients")]
    public async Task<IActionResult> Clients()
    {
        if (!IsAdmin()) return Unauthorized(new { error = "Non autorisé" });

        var rows = await _db.Scans
            .GroupBy(s => s.Username)
            .Select(g => new ClientDto(
                g.Key,
                g.Count(),
                g.Max(s => s.ScannedAt)
            ))
            .OrderByDescending(c => c.LastActivity)
            .ToListAsync();

        return Ok(rows);
    }
}
