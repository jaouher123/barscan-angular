using BarscanApi.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace BarscanApi.Controllers;

[ApiController]
[Route("api")]
public class AuthController : ControllerBase
{
    private readonly IConfiguration _config;
    public AuthController(IConfiguration config) => _config = config;

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Username))
            return BadRequest(new { error = "Nom d'utilisateur requis" });

        var adminPass = _config["AdminPass"] ?? "admin123";

        if (req.Role == "admin" && req.Password != adminPass)
            return Unauthorized(new { error = "Mot de passe incorrect" });

        return Ok(new LoginResponse(req.Username, req.Role ?? "operator"));
    }
}
