namespace BarscanApi.DTOs;

public record LoginRequest(string Username, string Role, string? Password);
public record LoginResponse(string Username, string Role);
public record CompareRequest(string Barcode1, string Barcode2, string Username);
public record ScanDto(int Id, string Barcode1, string Barcode2, string Result, string Username, DateTime ScannedAt);
public record StatsDto(int Total, int TotalOK, int TotalNOK, double ErrorRate);
public record CompareResponse(ScanDto Scan, StatsDto Stats);
public record HourlyDto(int Hour, int Ok, int Nok);
public record ClientDto(string Username, int ScanCount, DateTime LastActivity);
