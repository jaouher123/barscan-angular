import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { ScanComponent } from './components/scan/scan.component';
import { HistoryComponent } from './components/history/history.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'scan', component: ScanComponent },
  { path: 'history', component: HistoryComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: '**', redirectTo: '/login' }
];
