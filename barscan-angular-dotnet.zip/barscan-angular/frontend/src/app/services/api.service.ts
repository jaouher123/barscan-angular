import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Client, CompareResponse, HourlyData, Scan, Stats, User } from '../models/models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private base = 'http://localhost:5000/api';

  constructor(private http: HttpClient) {}

  private adminHeaders(): HttpHeaders {
    const pass = localStorage.getItem('adminPass') || '';
    return new HttpHeaders({ 'x-admin-pass': pass });
  }

  login(username: string, role: string, password?: string): Observable<User> {
    return this.http.post<User>(`${this.base}/login`, { username, role, password });
  }

  compare(barcode1: string, barcode2: string, username: string): Observable<CompareResponse> {
    return this.http.post<CompareResponse>(`${this.base}/scans/compare`, { barcode1, barcode2, username });
  }

  history(page = 1, pageSize = 25, searchCode = '', result = '', username = ''): Observable<Scan[]> {
    let params = new HttpParams()
      .set('page', page)
      .set('pageSize', pageSize);
    if (searchCode) params = params.set('searchCode', searchCode);
    if (result) params = params.set('result', result);
    if (username) params = params.set('username', username);
    return this.http.get<Scan[]>(`${this.base}/scans/history`, { params });
  }

  stats(username = ''): Observable<Stats> {
    let params = new HttpParams();
    if (username) params = params.set('username', username);
    return this.http.get<Stats>(`${this.base}/scans/stats`, { params });
  }

  hourly(): Observable<HourlyData[]> {
    return this.http.get<HourlyData[]>(`${this.base}/scans/hourly`);
  }

  exportCsv(username = ''): void {
    const params = username ? `?username=${username}` : '';
    window.open(`${this.base}/scans/export${params}`, '_blank');
  }

  clients(): Observable<Client[]> {
    return this.http.get<Client[]>(`${this.base}/admin/clients`, { headers: this.adminHeaders() });
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.base}/scans/all`, { headers: this.adminHeaders() });
  }
}
