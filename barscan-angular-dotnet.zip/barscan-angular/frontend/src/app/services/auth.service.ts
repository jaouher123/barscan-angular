import { Injectable, signal } from '@angular/core';
import { User } from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  currentUser = signal<User | null>(null);

  login(user: User, adminPass?: string): void {
    this.currentUser.set(user);
    if (adminPass) localStorage.setItem('adminPass', adminPass);
    localStorage.setItem('user', JSON.stringify(user));
  }

  logout(): void {
    this.currentUser.set(null);
    localStorage.removeItem('user');
    localStorage.removeItem('adminPass');
  }

  isAdmin(): boolean {
    return this.currentUser()?.role === 'admin';
  }

  restore(): void {
    const stored = localStorage.getItem('user');
    if (stored) this.currentUser.set(JSON.parse(stored));
  }
}
