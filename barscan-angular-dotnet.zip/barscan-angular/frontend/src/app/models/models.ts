export interface Scan {
  id: number;
  barcode1: string;
  barcode2: string;
  result: 'OK' | 'NOK';
  username: string;
  scannedAt: string;
}

export interface Stats {
  total: number;
  totalOK: number;
  totalNOK: number;
  errorRate: number;
}

export interface CompareResponse {
  scan: Scan;
  stats: Stats;
}

export interface HourlyData {
  hour: number;
  ok: number;
  nok: number;
}

export interface Client {
  username: string;
  scanCount: number;
  lastActivity: string;
}

export interface User {
  username: string;
  role: 'operator' | 'admin';
}
