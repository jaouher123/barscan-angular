import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private api = inject(ApiService);
  private auth = inject(AuthService);
  private router = inject(Router);

  username = '';
  role = 'operator';
  password = '';
  error = '';
  loading = false;

  onSubmit(): void {
    if (!this.username.trim()) { this.error = "Nom d'utilisateur requis"; return; }
    this.loading = true;
    this.error = '';

    this.api.login(this.username, this.role, this.role === 'admin' ? this.password : undefined)
      .subscribe({
        next: (user) => {
          this.auth.login(user, this.role === 'admin' ? this.password : undefined);
          this.router.navigate([this.role === 'admin' ? '/dashboard' : '/scan']);
        },
        error: () => {
          this.error = 'Identifiants incorrects';
          this.loading = false;
        }
      });
  }
}
