import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Scan, Stats } from '../../models/models';

@Component({
  selector: 'app-scan',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './scan.component.html',
  styleUrl: './scan.component.css'
})
export class ScanComponent implements OnInit {
  private api = inject(ApiService);
  public auth = inject(AuthService);
  private router = inject(Router);

  barcode1 = '';
  barcode2 = '';
  lastScan: Scan | null = null;
  stats: Stats = { total: 0, totalOK: 0, totalNOK: 0, errorRate: 0 };
  loading = false;
  error = '';

  ngOnInit(): void {
    if (!this.auth.currentUser()) this.router.navigate(['/login']);
    this.loadStats();
  }

  loadStats(): void {
    this.api.stats(this.auth.currentUser()?.username).subscribe({
      next: s => this.stats = s,
      error: () => {}
    });
  }

  compare(): void {
    if (!this.barcode1 || !this.barcode2) { this.error = 'Veuillez saisir les deux codes'; return; }
    this.loading = true;
    this.error = '';
    this.api.compare(this.barcode1, this.barcode2, this.auth.currentUser()?.username ?? '')
      .subscribe({
        next: res => {
          this.lastScan = res.scan;
          this.stats = res.stats;
          this.barcode1 = '';
          this.barcode2 = '';
          this.loading = false;
        },
        error: () => { this.error = 'Erreur lors de la comparaison'; this.loading = false; }
      });
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
