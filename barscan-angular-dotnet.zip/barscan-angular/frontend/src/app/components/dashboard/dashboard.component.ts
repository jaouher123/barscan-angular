import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Client, HourlyData, Stats } from '../../models/models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  private api = inject(ApiService);
  public auth = inject(AuthService);
  private router = inject(Router);

  stats: Stats = { total: 0, totalOK: 0, totalNOK: 0, errorRate: 0 };
  clients: Client[] = [];
  hourly: HourlyData[] = [];
  loading = false;

  ngOnInit(): void {
    if (!this.auth.isAdmin()) { this.router.navigate(['/scan']); return; }
    this.load();
  }

  load(): void {
    this.loading = true;
    this.api.stats().subscribe({ next: s => this.stats = s, error: () => {} });
    this.api.clients().subscribe({ next: c => { this.clients = c; this.loading = false; }, error: () => this.loading = false });
    this.api.hourly().subscribe({ next: h => this.hourly = h, error: () => {} });
  }

  getBarWidth(value: number): string {
    const max = Math.max(...this.hourly.map(h => h.ok + h.nok), 1);
    return `${(value / max) * 100}%`;
  }

  deleteAll(): void {
    if (!confirm('Supprimer TOUS les scans ? Cette action est irréversible.')) return;
    this.api.deleteAll().subscribe({ next: () => this.load(), error: () => alert('Erreur lors de la suppression') });
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  exportCsv(): void { this.api.exportCsv(); }
}
