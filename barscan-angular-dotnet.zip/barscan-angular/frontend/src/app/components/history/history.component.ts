import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Scan } from '../../models/models';

@Component({
  selector: 'app-history',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './history.component.html',
  styleUrl: './history.component.css'
})
export class HistoryComponent implements OnInit {
  private api = inject(ApiService);
  public auth = inject(AuthService);

  scans: Scan[] = [];
  page = 1;
  pageSize = 25;
  searchCode = '';
  resultFilter = '';
  loading = false;

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    const username = this.auth.isAdmin() ? '' : (this.auth.currentUser()?.username ?? '');
    this.api.history(this.page, this.pageSize, this.searchCode, this.resultFilter, username)
      .subscribe({ next: s => { this.scans = s; this.loading = false; }, error: () => this.loading = false });
  }

  search(): void { this.page = 1; this.load(); }
  prev(): void { if (this.page > 1) { this.page--; this.load(); } }
  next(): void { this.page++; this.load(); }

  exportCsv(): void {
    const username = this.auth.isAdmin() ? '' : (this.auth.currentUser()?.username ?? '');
    this.api.exportCsv(username);
  }
}
